# config.py
BOT_TOKEN = '7955193002:AAHMXa15LTyrsWKfyYMkoG0TyaAzCSdYPg0'
ADMIN_IDS = [456028350]  # Список адміністративних ID
